package sistema.pagamento;

public class PagamentoTransferencia implements MetodoPagamento {
    @Override
    public void processar(double valor) {
        System.out.println("[TRANSFERÊNCIA] Dados bancários: Ag 0001, Conta 12345-6");
        System.out.println("[TRANSFERÊNCIA] Valor: R$ " + valor);
        System.out.println("[TRANSFERÊNCIA] O processamento pode levar até 24h úteis.");
    }
}