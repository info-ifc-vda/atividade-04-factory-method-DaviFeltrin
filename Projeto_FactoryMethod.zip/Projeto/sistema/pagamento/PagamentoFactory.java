package sistema.pagamento;

public class PagamentoFactory {
    
    public static MetodoPagamento criarPagamento(String tipo) {
        if (tipo == null || tipo.isEmpty()) {
            throw new IllegalArgumentException("O tipo de pagamento deve ser informado.");
        }

        // Formato tradicional que funciona em qualquer versão do Java
        switch (tipo.toLowerCase().trim()) {
            case "cartao":
                return new PagamentoCartao();
            case "boleto":
                return new PagamentoBoleto();
            case "pix":
                return new PagamentoPix();
            case "transferencia":
                return new PagamentoTransferencia();
            default:
                throw new IllegalArgumentException("Forma de pagamento '" + tipo + "' não disponível.");
        }
    }
}