package sistema.pagamento;

public class PagamentoBoleto implements MetodoPagamento {
    @Override
    public void processar(double valor) {
        System.out.println("[BOLETO] Gerando boleto de R$ " + valor);
        System.out.println("[BOLETO] Código de barras: 34191.79001 01043.510047 91020.150008 9 95230000025050");
        System.out.println("[BOLETO] Disponível para pagamento até o vencimento.");
    }
}