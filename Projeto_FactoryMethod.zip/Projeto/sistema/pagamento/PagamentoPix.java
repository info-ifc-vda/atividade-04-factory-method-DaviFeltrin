package sistema.pagamento;

public class PagamentoPix implements MetodoPagamento {
    @Override
    public void processar(double valor) {
        System.out.println("[PIX] Gerando chave aleatória para R$ " + valor);
        System.out.println("[PIX] QR Code: 00020126360014BR.GOV.BCB.PIX0114+5511999999999");
        System.out.println("[PIX] Aguardando confirmação instantânea...");
    }
}