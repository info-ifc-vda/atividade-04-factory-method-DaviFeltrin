package sistema.pagamento;

public interface MetodoPagamento {
    void processar(double valor);
}
