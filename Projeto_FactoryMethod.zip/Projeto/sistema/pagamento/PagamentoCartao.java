package sistema.pagamento;

public class PagamentoCartao implements MetodoPagamento {
    @Override
    public void processar(double valor) {
        System.out.println("[CARTÃO] Processando R$ " + valor);
        System.out.println("[CARTÃO] Validando dados do titular e limite disponível...");
        System.out.println("[CARTÃO] Pagamento aprovado com sucesso!");
    }
}