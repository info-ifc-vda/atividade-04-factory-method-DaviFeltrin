package sistema;

import sistema.pagamento.MetodoPagamento;
import sistema.pagamento.PagamentoFactory;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("--- INICIANDO SISTEMA DE PAGAMENTO ---");

            // Exemplo 1: Cliente escolhe PIX
            MetodoPagamento p1 = PagamentoFactory.criarPagamento("pix");
            p1.processar(150.00);

            System.out.println("\n-------------------------------------\n");

            // Exemplo 2: Cliente escolhe Cartão
            MetodoPagamento p2 = PagamentoFactory.criarPagamento("cartao");
            p2.processar(890.99);

            System.out.println("\n-------------------------------------\n");

            // Exemplo 3: Tentativa com método inexistente
            MetodoPagamento p3 = PagamentoFactory.criarPagamento("cripto");
            p3.processar(10.00);

        } catch (IllegalArgumentException e) {
            System.err.println("Erro no processamento: " + e.getMessage());
        }
    }
}